rm -f *.txt
rm -f colord-scan*
rm -f colord.types
rm -rf html/
rm -rf tmpl/
rm -f *.stamp

