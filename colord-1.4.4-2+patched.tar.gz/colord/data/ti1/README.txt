targen -d3 -G -e4 -s5 -g17 -f64 display-short
targen -d3 -G -e4 -s5 -g17 -f128 display-normal
targen -d3 -G -e4 -s5 -g17 -f256 display-long
targen -d2 -G -f196 printer-short
targen -d2 -G -f392 printer-normal
targen -d2 -G -f588 printer-long
