/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*-
 *
 * Copyright (C) 2010-2012 Richard Hughes <richard@hughsie.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef __CD_DEVICE_H
#define __CD_DEVICE_H

#include <glib-object.h>

#include "cd-common.h"
#include "cd-profile.h"

G_BEGIN_DECLS

#define CD_DEVICE_ERROR		cd_device_error_quark()

#define CD_TYPE_DEVICE (cd_device_get_type ())
G_DECLARE_DERIVABLE_TYPE (CdDevice, cd_device, CD, DEVICE, GObject)

struct _CdDeviceClass
{
	GObjectClass		 parent_class;
	void			(* invalidate)		(CdDevice	*device);
};

CdDevice	*cd_device_new				(void);
GQuark		 cd_device_error_quark			(void);

/* accessors */
CdObjectScope	 cd_device_get_scope			(CdDevice	*device);
void		 cd_device_set_scope			(CdDevice	*device,
							 CdObjectScope	 object_scope);
void		 cd_device_set_owner			(CdDevice	*device,
							 guint		 owner);
guint		 cd_device_get_owner			(CdDevice	*device);
void		 cd_device_set_seat			(CdDevice	*device,
							 const gchar	*seat);
const gchar	*cd_device_get_seat			(CdDevice	*device);
CdDeviceMode	 cd_device_get_mode			(CdDevice	*device);
void		 cd_device_set_mode			(CdDevice	*device,
							 CdDeviceMode	 mode);
const gchar	*cd_device_get_model			(CdDevice	*device);
CdDeviceKind	 cd_device_get_kind			(CdDevice	*device);
void		 cd_device_set_kind			(CdDevice	*device,
							 CdDeviceKind	 kind);
const gchar	*cd_device_get_id			(CdDevice	*device);
void		 cd_device_set_id			(CdDevice	*device,
							 const gchar	*id);
gboolean	 cd_device_add_profile			(CdDevice	*device,
							 CdDeviceRelation relation,
							 const gchar	*profile_object_path,
							 guint64	 timestamp,
							 GError		**error)
							 G_GNUC_WARN_UNUSED_RESULT;
gboolean	 cd_device_remove_profile		(CdDevice	*device,
							 const gchar	*profile_object_path,
							 GError		**error)
							 G_GNUC_WARN_UNUSED_RESULT;
gboolean	 cd_device_make_default			(CdDevice	*device,
							 const gchar	*profile_object_path,
							 GError		**error)
							 G_GNUC_WARN_UNUSED_RESULT;
const gchar	*cd_device_get_object_path		(CdDevice	*device);
gboolean	 cd_device_register_object		(CdDevice	*device,
							 GDBusConnection *connection,
							 GDBusInterfaceInfo *info,
							 GError		**error)
							 G_GNUC_WARN_UNUSED_RESULT;
void		 cd_device_watch_sender			(CdDevice	*device,
							 const gchar	*sender);
gboolean	 cd_device_set_property_internal	(CdDevice	*device,
							 const gchar	*property,
							 const gchar	*value,
							 gboolean	 save_in_db,
							 GError		**error);
const gchar	*cd_device_get_metadata			(CdDevice	*device,
							 const gchar	*key);

G_END_DECLS

#endif /* __CD_DEVICE_H */

